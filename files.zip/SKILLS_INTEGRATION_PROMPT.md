# GEMINI CLI PROMPT — Skills Integration & Compatibility Review

## Paste this entire prompt into Gemini CLI after placing the 4 skill files into /skills/

---

I have added 4 new skill files to the project. Please do the following in order.

## STEP 1: READ ALL SKILL FILES

Read every file in /skills/:
- skills/clio_api_patterns.md
- skills/pdf_extraction_patterns.md
- skills/legal_domain_context.md
- skills/n8n_patterns.md

Understand the full content of each before making any changes.

## STEP 2: VERIFY GEMINI CLI COMPATIBILITY

For each skill file, check and fix the following without losing any content:

- All file paths must match the actual project structure exactly
  (agents/ not files/, ClientReports/ not sample_reports/, etc.)
- All code blocks must have correct language tags
  (```python, ```bash, ```javascript, ```json — never plain ```)
- All environment variable names must exactly match .env.template
- No duplicate content between skill files
- No references to paths or filenames that do not exist in this project
- Each skill file must have the WHO USES THIS SKILL section at the top
- Each skill file must have ENABLE THIS SKILL WHEN and DISABLE / SKIP WHEN

## STEP 3: UPDATE ALL AGENT FILES

For each file in /agents/, add a SKILLS section near the top
(after WHO YOU ARE, before WAIT FOR THIS):

Format:
```
## SKILLS TO LOAD
Before executing any task, read these skill files:
- [list only the skills actually relevant to this agent]

Do NOT load skills that are not relevant to your task.
```

Mapping:
- doc_intelligence.md → load: pdf_extraction_patterns.md, legal_domain_context.md
- clio_integration.md → load: clio_api_patterns.md, legal_domain_context.md
- n8n_architect.md → load: n8n_patterns.md, clio_api_patterns.md, pdf_extraction_patterns.md
- email_comms.md → load: legal_domain_context.md
- qa_reliability.md → load: all four skills
- technical_writer.md → load: legal_domain_context.md
- research_setup.md → load: clio_api_patterns.md, n8n_patterns.md
- critic_judge.md → load: all four skills
- client_simulator.md → load: legal_domain_context.md

## STEP 4: UPDATE GEMINI.md

Add a SKILLS REGISTRY section to the root GEMINI.md after the AGENTS table:

```
## SKILLS REGISTRY

| Skill File | Purpose | Loaded By |
|---|---|---|
| skills/clio_api_patterns.md | Clio API calls, OAuth, document automation | Agents 3, 4, 6, 8, 9 |
| skills/pdf_extraction_patterns.md | Claude PDF extraction, validation | Agents 2, 4, 6, 9 |
| skills/legal_domain_context.md | PI law, retainer, SOL, client tone | Agents 2, 3, 5, 7, 9, 10 |
| skills/n8n_patterns.md | n8n node patterns, code snippets | Agents 4, 6, 8, 9 |

Skills are read-only reference files.
Agents load skills at the start of their task.
Agents do not modify skill files.
Only the Orchestrator can update skill files if patterns change.
```

## STEP 5: CROSS-CHECK FOR CONFLICTS

Check for any conflicts between skill files and agent files:
- If a skill file defines a function, the agent file should not redefine it
- If paths differ between skill and agent, standardize to the skill version
- If code snippets contradict each other, the SKILL file version wins

Report any conflicts found.

## STEP 6: VALIDATE THE FULL SKILLS FOLDER STRUCTURE

After all edits, confirm the /skills/ folder contains exactly:
- skills/clio_api_patterns.md
- skills/pdf_extraction_patterns.md
- skills/legal_domain_context.md
- skills/n8n_patterns.md

And confirm no skill content was accidentally deleted during edits.

## STEP 7: FINAL REPORT

Give me:
1. List of all changes made to agent files
2. List of any conflicts found and how they were resolved
3. List of any file path corrections made
4. Confirmation that all 4 skills are Gemini CLI compatible
5. Any content that could not be verified without running the code

Do not ask questions. Execute all steps now.
Start with STEP 1.
